# Steam Hour Boost

### Installation
```bash
git clone https://github.com/vininjr/steam-hour-boost.git
cd steam-hour-boost
npm install
```

### Startup
```bash
node idlerConfig.js <YOUR_USERNAME> <YOUR_PASSWORD> optional<SHARED_KEY> optional<GAME_IDS>
```
